
package projeto;

import javax.swing.JOptionPane;
import java.io.*;

public class JanelaPedidos extends javax.swing.JFrame {
  //Variaveis
  String pedidos="",comentario,enderecoCliet,tamanho;
  Pilha pilha =new Pilha();
  Pedidos pedido;
  Pizza pizzaCliet=null;
  Borda bordaClit=null;
  Acompanhamento acompanhamento=null;
  
  boolean metadeClit;
  
    public JanelaPedidos() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        buttonGroup2 = new javax.swing.ButtonGroup();
        buttonGroup3 = new javax.swing.ButtonGroup();
        jLabel1 = new javax.swing.JLabel();
        label1 = new java.awt.Label();
        label2 = new java.awt.Label();
        jLabel2 = new javax.swing.JLabel();
        entrega = new javax.swing.JRadioButton();
        jLabel3 = new javax.swing.JLabel();
        Enviar = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        textComentarios = new javax.swing.JTextArea();
        jLabel4 = new javax.swing.JLabel();
        btnAdicionarAoPedido = new javax.swing.JButton();
        jScrollPane3 = new javax.swing.JScrollPane();
        areadopedido = new javax.swing.JTextPane();
        jLabel5 = new javax.swing.JLabel();
        metade = new javax.swing.JCheckBox();
        sabor1 = new javax.swing.JComboBox<>();
        sabor2 = new javax.swing.JComboBox<>();
        borda1 = new javax.swing.JComboBox<>();
        acompanha = new javax.swing.JComboBox<>();
        qtd = new javax.swing.JComboBox<>();
        jScrollPane1 = new javax.swing.JScrollPane();
        endereco = new javax.swing.JTextArea();
        local = new javax.swing.JRadioButton();
        pequena = new javax.swing.JCheckBox();
        media = new javax.swing.JCheckBox();
        grande = new javax.swing.JCheckBox();
        apagarUltimo = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Pizzaria Paneleiras");
        setBackground(java.awt.Color.yellow);

        jLabel1.setText("Tipos de pizza: ");
        jLabel1.setName("Tipos de Pizza"); // NOI18N

        label1.setName("Sabores: "); // NOI18N
        label1.setText("Borda:");

        label2.setName("Sabores: "); // NOI18N
        label2.setText("Sabor1:");

        jLabel2.setText("Forma de envio");
        jLabel2.setToolTipText("");

        buttonGroup2.add(entrega);
        entrega.setText("Entrega");
        entrega.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                entregaActionPerformed(evt);
            }
        });

        jLabel3.setText("Acompanhamento:");

        Enviar.setText("Enviar");
        Enviar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EnviarActionPerformed(evt);
            }
        });

        textComentarios.setColumns(20);
        textComentarios.setRows(5);
        jScrollPane2.setViewportView(textComentarios);

        jLabel4.setText("Comentarios");

        btnAdicionarAoPedido.setText("Adicionar ao pedido");
        btnAdicionarAoPedido.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAdicionarAoPedidoActionPerformed(evt);
            }
        });

        jScrollPane3.setViewportView(areadopedido);

        jLabel5.setText("Sabor2:");

        metade.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        metade.setText("Metade");
        metade.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                metadeActionPerformed(evt);
            }
        });

        sabor1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Mussarela", "Escarola", "Marguerita", "Atum", "Romana", "Calabresa", "Napolitana", "Brócolis", "Portuguesa", "Bacon", "Frango com Catupiry", "Chocolate", "Prestígio", "Beijinho", "M&M", "Nutella com Morango" }));
        sabor1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                sabor1ActionPerformed(evt);
            }
        });

        sabor2.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Nenhuma", "Mussarela", "Escarola", "Marguerita", "Atum", "Romana", "Calabresa ", "Napolitana ", "Brócolis ", "Portuguesa ", "Bacon ", "Frango com Catupiry", "Chocolate ", "Prestígio ", "Beijinho ", "M&M ", "Nutella com Morango" }));
        sabor2.setEnabled(false);
        sabor2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                sabor2ActionPerformed(evt);
            }
        });

        borda1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Sem borda", "Catupiry", "Cheddar", "Mussarela", "Chocolate", "Nutella" }));
        borda1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                borda1ActionPerformed(evt);
            }
        });

        acompanha.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Sem acompanhamento", "Guaraná ", "Coca cola ", "Coca cola zero", "Fanta laranja", "Fanta uva", "Água", "Suco de laranja" }));
        acompanha.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                acompanhaActionPerformed(evt);
            }
        });

        qtd.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "2Lts", "Lata" }));
        qtd.setEnabled(false);

        endereco.setColumns(20);
        endereco.setRows(5);
        endereco.setEnabled(false);
        jScrollPane1.setViewportView(endereco);

        buttonGroup2.add(local);
        local.setText("Local");
        local.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                localActionPerformed(evt);
            }
        });

        buttonGroup1.add(pequena);
        pequena.setText("Pequena");

        buttonGroup1.add(media);
        media.setText("Média");

        buttonGroup1.add(grande);
        grande.setText("Grande");

        apagarUltimo.setText("Apagar ultimo");
        apagarUltimo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                apagarUltimoActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(51, 51, 51)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel2)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(local)
                                    .addComponent(entrega))))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(11, 11, 11)
                                .addComponent(pequena)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(media)
                                .addGap(18, 18, 18)
                                .addComponent(grande)
                                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 629, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(label1, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(borda1, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(8, 8, 8)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jLabel4)
                                            .addGroup(layout.createSequentialGroup()
                                                .addComponent(jLabel3)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                .addComponent(acompanha, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                                    .addGroup(layout.createSequentialGroup()
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(label2, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(sabor2, javax.swing.GroupLayout.PREFERRED_SIZE, 145, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(94, 94, 94)
                                        .addComponent(sabor1, javax.swing.GroupLayout.PREFERRED_SIZE, 145, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addGap(0, 0, Short.MAX_VALUE)))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 354, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(Enviar, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(btnAdicionarAoPedido))
                                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(2, 2, 2)
                                .addComponent(metade)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 331, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addContainerGap())
                            .addGroup(layout.createSequentialGroup()
                                .addGap(18, 18, 18)
                                .addComponent(qtd, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(apagarUltimo)
                                .addGap(115, 115, 115))))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 289, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(apagarUltimo))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addContainerGap(106, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(pequena)
                            .addComponent(media)
                            .addComponent(grande))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(label2, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(sabor2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(metade, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(label1, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(10, 10, 10)
                                        .addComponent(borda1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(9, 9, 9)
                                .addComponent(sabor1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addGap(39, 39, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 21, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel2)
                        .addComponent(entrega)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(local)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(acompanha, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(qtd, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(31, 31, 31)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(btnAdicionarAoPedido, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGap(18, 18, 18)
                        .addComponent(Enviar, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jLabel4)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void metadeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_metadeActionPerformed
        //Metade:
        if(metade.isSelected()){
            sabor2.setEnabled(true);

        }else{
            sabor2.setEnabled(false);
        }
    }//GEN-LAST:event_metadeActionPerformed

    private void btnAdicionarAoPedidoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAdicionarAoPedidoActionPerformed
        //Adcionar pedido(Metodo principal):
        
        //Variaveis do metodo
        String pizzaSabor = (String)sabor1.getSelectedItem();
        String bordaSabor = (String)borda1.getSelectedItem();
        String pizzaSabor2=(String)sabor2.getSelectedItem();
        String bebida=(String)acompanha.getSelectedItem();
        String tamanhoBebida=(String)qtd.getSelectedItem();
        comentario=textComentarios.getText();
        
        //Ifs e elses
            //Acompanhamento
        if(bebida.equals("Sem acompanhamento")){
            tamanhoBebida="";
        }
        
            // Tamanho da pizza
        if(pequena.isSelected()){
            tamanho="Pequena";
        }else if(media.isSelected()){
            tamanho="Media";
        }else{
            tamanho="Grande";
        }
        
        //Verificar se vai se metade ou não
        if(metade.isSelected()){
            metadeClit=true;        
        }else{
            metadeClit=false;
            pizzaSabor2="Nenhuma";
        } 
        
        //Objetos
        acompanhamento=new Acompanhamento(bebida, tamanhoBebida);
        bordaClit= new Borda(bordaSabor);
        pizzaCliet=new Pizza(pizzaSabor,tamanho,metadeClit,pizzaSabor2);
        
        
        //Adicionar a Pilha
        pilha.push(pedido=new Pedidos(pizzaCliet,acompanhamento,bordaClit,comentario));
        
        //Finalizações
        pedidos+=pedido.toString()+"\n";   
        areadopedido.setText(pedidos);
        
    }//GEN-LAST:event_btnAdicionarAoPedidoActionPerformed

    private void EnviarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EnviarActionPerformed
    //Finalizar
    
    //Variaveis
    String pedidoTotal;
    
    //If e else para sabe se vai ser entregar ou não
    if(entrega.isSelected()){
        enderecoCliet=endereco.getText();
        
        pedidoTotal=pilha.toString(enderecoCliet,true);
    }else{
       enderecoCliet="";
        pedidoTotal=pilha.toString(enderecoCliet,false);
    }
        
        //Imprimir nota
        try {
            FileWriter writer = new FileWriter("Nota.txt");
            writer.write(pedidoTotal);
            writer.close();
		}catch (IOException e){
			e.printStackTrace();
		}
        //Finalizar programa
        JOptionPane.showMessageDialog(null,"Seu pedido foi finalizado");
        
    }//GEN-LAST:event_EnviarActionPerformed

    private void sabor1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_sabor1ActionPerformed
        //Sabor1:
      
    }//GEN-LAST:event_sabor1ActionPerformed

    private void sabor2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_sabor2ActionPerformed
        //Sabor2:
    }//GEN-LAST:event_sabor2ActionPerformed

    private void borda1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_borda1ActionPerformed
        // Borda:
    }//GEN-LAST:event_borda1ActionPerformed

    private void entregaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_entregaActionPerformed
        //Entrega:
         if(entrega.isSelected()){
            endereco.setEnabled(true);
            
        }else{
            endereco.setEnabled(false);
           
        }
        
    }//GEN-LAST:event_entregaActionPerformed

    private void localActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_localActionPerformed
        // Local:
        if(local.isSelected()){
            endereco.setEnabled(false);
        }else{
            endereco.setEnabled(true);
        }
    }//GEN-LAST:event_localActionPerformed

    private void acompanhaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_acompanhaActionPerformed
        //Acompanhamento:
        String ac = acompanha.getSelectedItem().toString();
        if(ac.equals("Sem acompanhamento")){
            qtd.setEnabled(false);
        }else{
            qtd.setEnabled(true);
        }
    }//GEN-LAST:event_acompanhaActionPerformed

    private void apagarUltimoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_apagarUltimoActionPerformed
        pilha.pop();   
        areadopedido.setText(pedido.toString());
    }//GEN-LAST:event_apagarUltimoActionPerformed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(JanelaPedidos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(JanelaPedidos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(JanelaPedidos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(JanelaPedidos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new JanelaPedidos().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Enviar;
    private javax.swing.JComboBox<String> acompanha;
    private javax.swing.JButton apagarUltimo;
    private javax.swing.JTextPane areadopedido;
    public javax.swing.JComboBox<String> borda1;
    private javax.swing.JButton btnAdicionarAoPedido;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.ButtonGroup buttonGroup2;
    private javax.swing.ButtonGroup buttonGroup3;
    public javax.swing.JTextArea endereco;
    public javax.swing.JRadioButton entrega;
    public javax.swing.JCheckBox grande;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private java.awt.Label label1;
    private java.awt.Label label2;
    public javax.swing.JRadioButton local;
    public javax.swing.JCheckBox media;
    public javax.swing.JCheckBox metade;
    public javax.swing.JCheckBox pequena;
    private javax.swing.JComboBox<String> qtd;
    public javax.swing.JComboBox<String> sabor1;
    public javax.swing.JComboBox<String> sabor2;
    private javax.swing.JTextArea textComentarios;
    // End of variables declaration//GEN-END:variables
}
